const { getMessage } = require('../lib/languages');

let handler = async (m, { conn, command }) => {
    // Get user's preferred language
    const user = global.db.data.users[m.sender];
    const chat = global.db.data.chats[m.chat];
    const lang = user?.language || chat?.language || global.language;
 {
  await conn.reply(m.chat, wait, m)
  try {
    if (command == 'gay') {
      const res = `https://api.betabotz.eu.org/fire/nsfw/gay?apikey=${lann}`;
      await conn.sendFile(m.chat, res, 'nsfw.jpg', '', m);
    }
    if (command == 'ahegao') {
      const res = `https://api.betabotz.eu.org/fire/nsfw/ahegao?apikey=${lann}`;
      await conn.sendFile(m.chat, res, 'nsfw.jpg', '', m);
    }
    if (command == 'ass') {
      const res = `https://api.betabotz.eu.org/fire/nsfw/ass?apikey=${lann}`;
      await conn.sendFile(m.chat, res, 'nsfw.jpg', '', m);
    }
    if (command == 'bdsm') {
      const res = `https://api.betabotz.eu.org/fire/nsfw/bdsm?apikey=${lann}`;
      await conn.sendFile(m.chat, res, 'nsfw.jpg', '', m);
    }
    if (command == 'blowjob') {
      const res = `https://api.betabotz.eu.org/fire/nsfw/blowjob?apikey=${lann}`;
      await conn.sendFile(m.chat, res, 'nsfw.jpg', '', m);
    }
     if (command == 'cuckold') {
      const res = `https://api.betabotz.eu.org/fire/nsfw/cuckold?apikey=ct${lann}`;
      await conn.sendFile(m.chat, res, 'nsfw.jpg', '', m);
    }
    if (command == 'cum') {
      const res = `https://api.betabotz.eu.org/fire/nsfw/cum?apikey=${lann}`;
      await conn.sendFile(m.chat, res, 'nsfw.jpg', '', m);
    }
    if (command == 'ero') {
      const res = `https://api.betabotz.eu.org/fire/nsfw/ero?apikey=${lann}`;
      await conn.sendFile(m.chat, res, 'nsfw.jpg', '', m);
    }
    if (command == 'femdom') {
      const res = `https://api.betabotz.eu.org/fire/nsfw/femdom?apikey=${lann}`;
      await conn.sendFile(m.chat, res, 'nsfw.jpg', '', m);
    }
    if (command == 'foot') {
      const res = `https://api.betabotz.eu.org/fire/nsfw/foot?apikey=${lann}`;
      await conn.sendFile(m.chat, res, 'nsfw.jpg', '', m);
    }
    if (command == 'gangbang') {
      const res = `https://api.betabotz.eu.org/fire/nsfw/gangbang?apikey=${lann}`;
      await conn.sendFile(m.chat, res, 'nsfw.jpg', '', m);
    }
    if (command == 'glasses') {
      const res = `https://api.betabotz.eu.org/fire/nsfw/glasses?apikey=${lann}`;
      await conn.sendFile(m.chat, res, 'nsfw.jpg', '', m);
    }
    if (command == 'hentai') {
      const res = `https://api.betabotz.eu.org/fire/nsfw/hentai?apikey=${lann}`;
      await conn.sendFile(m.chat, res, 'nsfw.jpg', '', m);
    }
    if (command == 'gifs') {
      const res = `https://api.betabotz.eu.org/fire/nsfw/gifs?apikey=${lann}`;
      await conn.sendFile(m.chat, res, null, '', m);
    }
    if (command == 'jahy') {
      const res = `https://api.betabotz.eu.org/fire/nsfw/jahy?apikey=${lann}`;
      await conn.sendFile(m.chat, res, 'nsfw.jpg', '', m);
    }
    if (command == 'manga') {
      const res = `https://api.betabotz.eu.org/fire/nsfw/manga?apikey=${lann}`;
      await conn.sendFile(m.chat, res, 'nsfw.jpg', '', m);
    }
    if (command == 'masturbation') {
      const res = `https://api.betabotz.eu.org/fire/nsfw/masturbation?apikey=${lann}`;
      await conn.sendFile(m.chat, res, 'nsfw.jpg', '', m);
    }
    if (command == 'neko') {
      const res = `https://api.betabotz.eu.org/fire/nsfw/neko?apikey=${lann}`;
      await conn.sendFile(m.chat, res, 'nsfw.jpg', '', m);
    }
    if (command == 'neko2') {
      const res = `https://api.betabotz.eu.org/fire/nsfw/neko2?apikey=${lann}`;
      await conn.sendFile(m.chat, res, 'nsfw.jpg', '', m);
    }
    if (command == 'orgy') {
      const res = `https://api.betabotz.eu.org/fire/nsfw/orgy?apikey=${lann}`;
      await conn.sendFile(m.chat, res, 'nsfw.jpg', '', m);
    }
    if (command == 'panties') {
      const res = `https://api.betabotz.eu.org/fire/nsfw/panties?apikey=${lann}`;
      await conn.sendFile(m.chat, res, 'nsfw.jpg', '', m);
    }
    if (command == 'pussy') {
      const res = `https://api.betabotz.eu.org/fire/nsfw/pussy?apikey=${lann}`;
      await conn.sendFile(m.chat, res, 'nsfw.jpg', '', m);
    }
    if (command == 'tentacles') {
      const res = `https://api.betabotz.eu.org/fire/nsfw/tentacles?apikey=${lann}`;
      await conn.sendFile(m.chat, res, 'nsfw.jpg', '', m);
    }
    if (command == 'yuri') {
      const res = `https://api.betabotz.eu.org/fire/nsfw/yuri?apikey=${lann}`;
      await conn.sendFile(m.chat, res, 'nsfw.jpg', '', m);
    }
    if (command == 'thighs') {
      const res = `https://api.betabotz.eu.org/fire/nsfw/thighs?apikey=${lann}`;
      await conn.sendFile(m.chat, res, 'nsfw.jpg', '', m);
    }
    if (command == 'zettai') {
      const res = `https://api.betabotz.eu.org/fire/nsfw/zettai?apikey=${lann}`;
      await conn.sendFile(m.chat, res, 'nsfw.jpg', '', m);
    }
   } catch (err) {
  console.error(err)
  throw "🚩 An error occurred"
   };
};
handler.command = handler.help = ['gay','ahegao','ass','bdsm','blowjob','cuckold','cum','ero','femdom','foot','gangbang','glasses','hentai','gifs','jahy','manga','masturbation','neko','neko2','orgy','tentacles','pussy','panties','thighs','yuri','zettai','lingerie','cosplay','uniform','swimsuit','bikini','underwear','schooluniform','lewd-cosplay']
handler.tags = ['nsfw']
handler.limit = true;
}

module.exports = handler;
